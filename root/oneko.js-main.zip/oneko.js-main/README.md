# oneko.js

A hacky script I wrote to put a cat on my site.